package 16309004jdbc;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.sql.PreparedStatement;
import java.sql.CallableStatement;
import java.sql.Date;

public class 16309004jdbc {
    static Connection conn = null;
    
    public static void main(String[] args) throws SQLException{
        String query_data = "select *" + "from candidates";
        
        try(Connection co = Practice_class_connection_to_mysql.getConnection();
               Statement stmt = co.createStatement();
                ){
            Practice_class_connection_to_mysql.querying_data(stmt,query_data);
            Practice_class_connection_to_mysql.update_data(conn);
            Practice_class_connection_to_mysql.insert_data_and_transaction(conn);
            Practice_class_connection_to_mysql.call_procedure(co,122);
            write_blob(conn,122, "johndoe_resume_from_db.txt");   
            read_blob(conn,122,"johndoe_resume_from_db.txt");
           }catch(SQLException e){
               System.out.println(e.getMessage());
           }finally{
            try{
                if(conn != null)
                   conn.close();
            }catch(SQLException ex){
                System.out.println(ex.getMessage());
            }
        }
    }
    
    public static Connection getConnection() throws SQLException{
        try//(FileInputStream f = new FileInputStream("db.properties"))
        {
            String url = "jdbc:mysql://localhost:3306/mysqljdbc";
            String user = "root";
            String password = "Passw0rd";
 
            //Properties pros = new Properties();
            //pros.load(f);
            
            //String url      = pros.getProperty("url");
            //String user     = pros.getProperty("user");
            //String password = pros.getProperty("password");
            
            conn = DriverManager.getConnection(url, user, password);
            
            System.out.println("Connect successfully!");
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return conn;
    }
    
    
    public static void querying_data(Statement stmt,String sql){
        try{
        ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                System.out.println(rs.getString("first_name")+"  "+rs.getString("last_name")+"  "+rs.getString("email")+"\n");
            }
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
    
    public static void update_data(Connection co){
        String update_date = "update candidates set last_name = ? where id = ?";
        try{
            PreparedStatement pstmt = co.prepareStatement(update_date);
            String lastname = "William";
            int id = 100;
            pstmt.setString(1,lastname);
            pstmt.setInt(2,id);
            
            int rowAffected = pstmt.executeUpdate();
            System.out.println(String.format("Row affected %d", rowAffected));
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
    
    public static void insert_data_and_transaction(Connection co){
        String insert_data = "insert into candidates(first_name,last_name,dob,phone,email)values(?,?,?,?,?)";
        int candidateId = 0;
        ResultSet rs = null;
        PreparedStatement pstmtAssignment = null;
        int[] skills = {1,2,3};
  
        try(PreparedStatement pstmt = co.prepareStatement(insert_data,Statement.RETURN_GENERATED_KEYS)){
            co.setAutoCommit(false);
            
            pstmt.setString(1,"Bushss");
            pstmt.setString(2,"Lilyss");
            pstmt.setDate(3,Date.valueOf("1980-01-04"));
            pstmt.setString(4,"1111");
            pstmt.setString(5, "111111@bjtu.edu.cn");
            
            int rowAffected = pstmt.executeUpdate();
            if(rowAffected == 1)
            {
                rs = pstmt.getGeneratedKeys();
                if(rs.next())
                    candidateId = rs.getInt(1);
                
                String sqlPivot = "insert into candidate_skills(candidate_id,skill_id)values(?,?)";
                pstmtAssignment = co.prepareStatement(sqlPivot);
                for(int skillId:skills){
                    pstmtAssignment.setInt(1,candidateId);
                    pstmtAssignment.setInt(2, skillId);
                    pstmtAssignment.executeUpdate();
                }
                co.commit();
            } else{
                co.rollback();
            }
            System.out.println(String.format("A new candidate with id %d has been inserted", candidateId));
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
    
    public static void call_procedure(Connection co,int candidateId){
        String query = "{call get_candidate_skill(?)}";
        ResultSet rs;
        
        try(CallableStatement stmt = co.prepareCall(query)){
            stmt.setInt(1,candidateId);
            rs = stmt.executeQuery();
            while(rs.next()){
                System.out.println(String.format("%s - %s", rs.getString("first_name")+" "+rs.getString("last_name"),rs.getString("skill")));
            }
            
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
    
    public static void write_blob(Connection co,int candidateId,String filename){
       String updateSQL = "UPDATE candidates "+ "SET email = ? "+ "WHERE id=?";
        
        try(PreparedStatement pstmt = co.prepareStatement(updateSQL)){
            File file = new File(filename);
            FileInputStream input = new FileInputStream(file);
            
            pstmt.setBinaryStream(1,input);
            pstmt.setInt(2, candidateId);
            
            System.out.println("Reading file " + file.getAbsolutePath());
            System.out.println("Store file in the database.");
            pstmt.executeUpdate();
 
        }catch(SQLException | FileNotFoundException e){
            System.out.println(e.getMessage());
        }
    }
    
    public static void read_blob(Connection co,int candidateId,String filename){
        String selectSQL = "SELECT email FROM candidates WHERE id=?";
        ResultSet rs = null;
 
        try (PreparedStatement pstmt = conn.prepareStatement(selectSQL);) {
            pstmt.setInt(1, candidateId);
            rs = pstmt.executeQuery();
            File file = new File(filename);
            FileOutputStream output = new FileOutputStream(file);
 
            System.out.println("Writing to file " + file.getAbsolutePath());
            while (rs.next()) {
                InputStream input = rs.getBinaryStream("email");
                byte[] buffer = new byte[1024];
                while (input.read(buffer) > 0) {
                    output.write(buffer);
                }
            }
        } catch (SQLException | IOException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
    }
    
}
